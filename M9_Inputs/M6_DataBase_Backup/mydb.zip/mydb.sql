-- MariaDB dump 10.19  Distrib 10.5.23-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: mydb
-- ------------------------------------------------------
-- Server version	10.5.23-MariaDB-1:10.5.23+maria~ubu2004

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Sequence structure for `srno1`
--

DROP SEQUENCE IF EXISTS `srno1`;
CREATE SEQUENCE `srno1` start with 1 minvalue 1 maxvalue 9223372036854775806 increment by 1 cache 1000 nocycle ENGINE=InnoDB;
SELECT SETVAL(`srno1`, 1, 0);

--
-- Table structure for table `Account`
--

DROP TABLE IF EXISTS `Account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Account` (
  `AccountID` int(10) unsigned NOT NULL,
  `AccountNo` int(10) unsigned NOT NULL,
  `PersonID` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`AccountID`),
  KEY `PersonID` (`PersonID`),
  CONSTRAINT `Account_ibfk_1` FOREIGN KEY (`PersonID`) REFERENCES `Person` (`PersonID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Account`
--

LOCK TABLES `Account` WRITE;
/*!40000 ALTER TABLE `Account` DISABLE KEYS */;
/*!40000 ALTER TABLE `Account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Accountssp`
--

DROP TABLE IF EXISTS `Accountssp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Accountssp` (
  `account_id` int(11) DEFAULT NULL,
  `income` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Accountssp`
--

LOCK TABLES `Accountssp` WRITE;
/*!40000 ALTER TABLE `Accountssp` DISABLE KEYS */;
INSERT INTO `Accountssp` VALUES (3,108939),(2,12747),(8,87709),(6,91796);
/*!40000 ALTER TABLE `Accountssp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BC_NF`
--

DROP TABLE IF EXISTS `BC_NF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BC_NF` (
  `StudentID` int(11) DEFAULT NULL,
  `SubjectName` varchar(80) DEFAULT NULL,
  `Profesor` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BC_NF`
--

LOCK TABLES `BC_NF` WRITE;
/*!40000 ALTER TABLE `BC_NF` DISABLE KEYS */;
INSERT INTO `BC_NF` VALUES (10,'SQL','Prof.SQL'),(20,'Python','Prof.Python'),(30,'Java','Prof.Java'),(50,'SQL','Prof.SQL');
/*!40000 ALTER TABLE `BC_NF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BC_NF_1`
--

DROP TABLE IF EXISTS `BC_NF_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BC_NF_1` (
  `StudentID` int(11) DEFAULT NULL,
  `ProfesorID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BC_NF_1`
--

LOCK TABLES `BC_NF_1` WRITE;
/*!40000 ALTER TABLE `BC_NF_1` DISABLE KEYS */;
INSERT INTO `BC_NF_1` VALUES (10,100),(20,101),(30,102),(50,100);
/*!40000 ALTER TABLE `BC_NF_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BC_NF_2`
--

DROP TABLE IF EXISTS `BC_NF_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BC_NF_2` (
  `ProfesorID` int(11) DEFAULT NULL,
  `Subject` varchar(10) DEFAULT NULL,
  `Profesor` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BC_NF_2`
--

LOCK TABLES `BC_NF_2` WRITE;
/*!40000 ALTER TABLE `BC_NF_2` DISABLE KEYS */;
INSERT INTO `BC_NF_2` VALUES (10,'SQL','Prof_SQL'),(20,'Java','Prof_Java'),(30,'python','Prof_python'),(50,'SQL','Prof_SQL');
/*!40000 ALTER TABLE `BC_NF_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Burn`
--

DROP TABLE IF EXISTS `Burn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Burn` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Burn`
--

LOCK TABLES `Burn` WRITE;
/*!40000 ALTER TABLE `Burn` DISABLE KEYS */;
INSERT INTO `Burn` VALUES (1,'first'),(2,'second'),(4,'third');
/*!40000 ALTER TABLE `Burn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CUST_BR1`
--

DROP TABLE IF EXISTS `CUST_BR1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CUST_BR1` (
  `CID` char(3) DEFAULT NULL,
  `CNAME` varchar(20) DEFAULT NULL,
  `MOBILE` int(10) DEFAULT NULL,
  `CITY` varchar(20) DEFAULT NULL,
  `GENDER` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CUST_BR1`
--

LOCK TABLES `CUST_BR1` WRITE;
/*!40000 ALTER TABLE `CUST_BR1` DISABLE KEYS */;
INSERT INTO `CUST_BR1` VALUES ('C1','VIJAY',1212121212,'HYD','MALE'),('C2','JOHN',1313131313,'DELHI','MALE'),('C3','SWATHI',1414141414,'HYD','FEMALE');
/*!40000 ALTER TABLE `CUST_BR1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CUST_BR2`
--

DROP TABLE IF EXISTS `CUST_BR2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CUST_BR2` (
  `CID` char(3) DEFAULT NULL,
  `CNAME` varchar(20) DEFAULT NULL,
  `MOBILE` bigint(20) DEFAULT NULL,
  `CITY` varchar(20) DEFAULT NULL,
  `GENDER` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CUST_BR2`
--

LOCK TABLES `CUST_BR2` WRITE;
/*!40000 ALTER TABLE `CUST_BR2` DISABLE KEYS */;
INSERT INTO `CUST_BR2` VALUES ('C1','KIRAN',9898989898,'HYD','MALE'),('C2','JOHN',1313131313,'DELHI','MALE'),('C3','LAKSHMI',8989898989,'DELHI','FEMALE');
/*!40000 ALTER TABLE `CUST_BR2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CUST_BR3`
--

DROP TABLE IF EXISTS `CUST_BR3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CUST_BR3` (
  `CID` char(3) DEFAULT NULL,
  `CNAME` varchar(20) DEFAULT NULL,
  `MOBILE` bigint(20) DEFAULT NULL,
  `CITY` varchar(20) DEFAULT NULL,
  `GENDER` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CUST_BR3`
--

LOCK TABLES `CUST_BR3` WRITE;
/*!40000 ALTER TABLE `CUST_BR3` DISABLE KEYS */;
INSERT INTO `CUST_BR3` VALUES ('C1','KIRAN',9898989898,'HYD','MALE'),('C2','JOHN',1313131313,'DELHI','MALE1'),('C5','VINAY',7878787878,'DELHI','MALE1');
/*!40000 ALTER TABLE `CUST_BR3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ClonedPersons`
--

DROP TABLE IF EXISTS `ClonedPersons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ClonedPersons` (
  `LastName` varchar(66) NOT NULL,
  `FirstName` varchar(66) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ClonedPersons`
--

LOCK TABLES `ClonedPersons` WRITE;
/*!40000 ALTER TABLE `ClonedPersons` DISABLE KEYS */;
INSERT INTO `ClonedPersons` VALUES ('10','100');
/*!40000 ALTER TABLE `ClonedPersons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `First_1NF`
--

DROP TABLE IF EXISTS `First_1NF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `First_1NF` (
  `EmployeeID` int(11) DEFAULT NULL,
  `EmployeeName` varchar(80) DEFAULT NULL,
  `PhoneNumber` bigint(20) DEFAULT NULL,
  `Salary` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `First_1NF`
--

LOCK TABLES `First_1NF` WRITE;
/*!40000 ALTER TABLE `First_1NF` DISABLE KEYS */;
INSERT INTO `First_1NF` VALUES (10,'First',4444455555,60),(20,'Second',99999,20),(30,'Third',11111,10),(50,'Fourth',2222299999,30);
/*!40000 ALTER TABLE `First_1NF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `First_1NF_2`
--

DROP TABLE IF EXISTS `First_1NF_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `First_1NF_2` (
  `EmployeeID` int(11) DEFAULT NULL,
  `EmployeeName` varchar(80) DEFAULT NULL,
  `PhoneNumber` bigint(20) DEFAULT NULL,
  `Salary` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `First_1NF_2`
--

LOCK TABLES `First_1NF_2` WRITE;
/*!40000 ALTER TABLE `First_1NF_2` DISABLE KEYS */;
INSERT INTO `First_1NF_2` VALUES (10,'First',44444,60),(10,'First',55555,60),(20,'Second',99999,20),(30,'Third',11111,10),(50,'Fourth',99999,30),(50,'Fourth',99999,30);
/*!40000 ALTER TABLE `First_1NF_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ModifiedPersons`
--

DROP TABLE IF EXISTS `ModifiedPersons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ModifiedPersons` (
  `PersonID` int(10) unsigned NOT NULL,
  `FullName` double DEFAULT NULL,
  PRIMARY KEY (`PersonID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ModifiedPersons`
--

LOCK TABLES `ModifiedPersons` WRITE;
/*!40000 ALTER TABLE `ModifiedPersons` DISABLE KEYS */;
INSERT INTO `ModifiedPersons` VALUES (1,110);
/*!40000 ALTER TABLE `ModifiedPersons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PER_INCR`
--

DROP TABLE IF EXISTS `PER_INCR`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PER_INCR` (
  `INCRID` int(11) DEFAULT NULL,
  `INCRVAL` varchar(20) DEFAULT NULL,
  `DESCRIPTION` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PER_INCR`
--

LOCK TABLES `PER_INCR` WRITE;
/*!40000 ALTER TABLE `PER_INCR` DISABLE KEYS */;
INSERT INTO `PER_INCR` VALUES (101,'5%','Min INcrement'),(102,'10%','Second level INcrement'),(103,'15%','3rd level INcrement'),(104,'25%','Max level INcrement');
/*!40000 ALTER TABLE `PER_INCR` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROCESS_LIST`
--

DROP TABLE IF EXISTS `PROCESS_LIST`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `PROCESS_LIST` (
  `ID` int(11) DEFAULT NULL,
  `CATEGORY` varchar(250) DEFAULT NULL,
  `INTEREST` varchar(250) DEFAULT NULL,
  `PRODUCT` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `PROCESS_LIST`
--

LOCK TABLES `PROCESS_LIST` WRITE;
/*!40000 ALTER TABLE `PROCESS_LIST` DISABLE KEYS */;
/*!40000 ALTER TABLE `PROCESS_LIST` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Patients_ps`
--

DROP TABLE IF EXISTS `Patients_ps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Patients_ps` (
  `patient_id` int(11) DEFAULT NULL,
  `patient_name` varchar(30) DEFAULT NULL,
  `conditions` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Patients_ps`
--

LOCK TABLES `Patients_ps` WRITE;
/*!40000 ALTER TABLE `Patients_ps` DISABLE KEYS */;
INSERT INTO `Patients_ps` VALUES (1,'Daniel','YFEV COUGH'),(2,'Alice',''),(3,'Bob','DIAB100 MYOP'),(4,'George','ACNE DIAB100'),(5,'Alain','DIAB201');
/*!40000 ALTER TABLE `Patients_ps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Person`
--

DROP TABLE IF EXISTS `Person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Person` (
  `PersonID` int(10) unsigned NOT NULL,
  `LastName` varchar(66) NOT NULL,
  `FirstName` varchar(66) DEFAULT NULL,
  `Address` varchar(255) DEFAULT NULL,
  `City` varchar(66) DEFAULT NULL,
  PRIMARY KEY (`PersonID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Person`
--

LOCK TABLES `Person` WRITE;
/*!40000 ALTER TABLE `Person` DISABLE KEYS */;
INSERT INTO `Person` VALUES (1,'10','100','chennai','chennai');
/*!40000 ALTER TABLE `Person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Product`
--

DROP TABLE IF EXISTS `Product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Product` (
  `ProductCategory` varchar(10) NOT NULL,
  `Brand` varchar(20) NOT NULL,
  `productname` varchar(15) NOT NULL,
  `price` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Product`
--

LOCK TABLES `Product` WRITE;
/*!40000 ALTER TABLE `Product` DISABLE KEYS */;
INSERT INTO `Product` VALUES ('Phone','Apple','iphone',1300),('Phone','Apple','iphone12pro',1100),('Phone','Apple','iphone12',1000),('Phone','Samsung','Galaxy1',1800),('Phone','Samsung','Galaxyfold',1000),('Phone','Samsung','Galaxy12',1200),('Phone','Samsung','Galaxy3',1000),('Phone','Oneplus','OneplusNord',300),('Phone','Oneplus','Oneplus9',800),('Phone','Google','Pixel5',600),('Laptop','Apple','Pixel5',600),('Phone','Google','MacBookPro13',2000),('Laptop','Apple','iphone',1300),('Laptop','Micrsoft','man',2100),('Laptop','Dell','xps12',2000),('Laptop','Dell','xps13',2300),('Earphone','Samsung','buds32',200),('Earphone','Aple','buds123',300),('Earphone','Samsung','airduds',200),('Headphone','Sony','WFX123',200),('Headphone','Aple','WFX12',300),('Headphone','Samsung','samhead123',200);
/*!40000 ALTER TABLE `Product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Products`
--

DROP TABLE IF EXISTS `Products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Products` (
  `product_id` int(11) DEFAULT NULL,
  `product_name` varchar(50) DEFAULT NULL,
  `Width` int(11) DEFAULT NULL,
  `Length` int(11) DEFAULT NULL,
  `Height` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Products`
--

LOCK TABLES `Products` WRITE;
/*!40000 ALTER TABLE `Products` DISABLE KEYS */;
INSERT INTO `Products` VALUES (1,'LC-TV',5,50,40),(2,'LC-KeyChain',5,5,5),(3,'LC-Phone',2,10,10),(4,'LC-T-Shirt',4,10,20);
/*!40000 ALTER TABLE `Products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Productv1`
--

DROP TABLE IF EXISTS `Productv1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Productv1` (
  `ProductCategory` varchar(10) NOT NULL,
  `Brand` varchar(20) NOT NULL,
  `productname` varchar(15) NOT NULL,
  `price` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Productv1`
--

LOCK TABLES `Productv1` WRITE;
/*!40000 ALTER TABLE `Productv1` DISABLE KEYS */;
INSERT INTO `Productv1` VALUES ('Phone','Apple','iphone',1300),('Phone','Apple','iphone12pro',1100),('Phone','Apple','iphone12',1000),('Phone','Samsung','Galaxy1',1800),('Phone','Samsung','Galaxyfold',1000),('Phone','Samsung','Galaxy12',1200),('Phone','Samsung','Galaxy3',1000),('Phone','Oneplus','OneplusNord',300),('Phone','Oneplus','Oneplus9',800),('Phone','Google','Pixel5',600),('Laptop','Apple','Pixel5',600),('Phone','Google','MacBookPro13',2000),('Laptop','Apple','iphone',1300),('Laptop','Micrsoft','man',2100),('Laptop','Dell','xps12',2000),('Laptop','Dell','xps13',2300),('Earphone','Samsung','buds32',200),('Earphone','Aple','buds123',300),('Earphone','Samsung','airduds',200),('Headphone','Sony','WFX123',200),('Headphone','Aple','WFX12',300),('Headphone','Samsung','samhead123',200);
/*!40000 ALTER TABLE `Productv1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Sales`
--

DROP TABLE IF EXISTS `Sales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Sales` (
  `Store_id` int(11) DEFAULT NULL,
  `store_name` varchar(16) DEFAULT NULL,
  `product` varchar(16) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `cost` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Sales`
--

LOCK TABLES `Sales` WRITE;
/*!40000 ALTER TABLE `Sales` DISABLE KEYS */;
INSERT INTO `Sales` VALUES (1,'Apple Orginal1','Iphone 12 pro',1,1000),(1,'Apple Orginal1','macbook pro 13',3,2000),(1,'Apple Orginal1','airpods pro',2,280),(2,'Apple Orginal2','Iphone 12 pro',2,1000),(3,'Apple Orginal3','Iphone 12 pro',1,1000),(3,'Apple Orginal3','macbook pro 13',1,2000),(3,'Apple Orginal3','macbook air',4,1100),(3,'Apple Orginal3','Iphone 12',2,1000),(3,'Apple Orginal3','airpods pro',3,280),(4,'Apple Orginal4','Iphone 12 pro',2,1000),(4,'Apple Orginal4','macbook pro 13',1,2500);
/*!40000 ALTER TABLE `Sales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Salesv1`
--

DROP TABLE IF EXISTS `Salesv1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Salesv1` (
  `Store_id` int(11) DEFAULT NULL,
  `product` varchar(16) DEFAULT NULL,
  `cost` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Salesv1`
--

LOCK TABLES `Salesv1` WRITE;
/*!40000 ALTER TABLE `Salesv1` DISABLE KEYS */;
INSERT INTO `Salesv1` VALUES (11,'MacBookPro13',2000),(11,'MacBookPro13',NULL),(11,'MacBookPro13',2000),(11,'MacBookPro13',2000),(100,'MacBookPro13',2000),(11,NULL,2000),(11,'MacBookPro13',2000),(11,'MacBookPro13',2000),(11,'MacBookPro13',2000),(11,'MacBookPro13',2000),(11,'iphone12',1000),(11,'iphone12',1000);
/*!40000 ALTER TABLE `Salesv1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Second_2NF`
--

DROP TABLE IF EXISTS `Second_2NF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Second_2NF` (
  `student_id` tinyint(3) unsigned DEFAULT NULL,
  `student_name` varchar(10) DEFAULT NULL,
  `address` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Second_2NF`
--

LOCK TABLES `Second_2NF` WRITE;
/*!40000 ALTER TABLE `Second_2NF` DISABLE KEYS */;
INSERT INTO `Second_2NF` VALUES (10,'100','pune'),(11,'111','Cheanni'),(12,'123','delhi'),(13,'134','Mumbai');
/*!40000 ALTER TABLE `Second_2NF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Second_2NF_1`
--

DROP TABLE IF EXISTS `Second_2NF_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Second_2NF_1` (
  `sub_id` tinyint(3) unsigned DEFAULT NULL,
  `Sub_Name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Second_2NF_1`
--

LOCK TABLES `Second_2NF_1` WRITE;
/*!40000 ALTER TABLE `Second_2NF_1` DISABLE KEYS */;
INSERT INTO `Second_2NF_1` VALUES (10,'100'),(11,'111'),(12,'123'),(13,'134');
/*!40000 ALTER TABLE `Second_2NF_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Second_2NF_2`
--

DROP TABLE IF EXISTS `Second_2NF_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Second_2NF_2` (
  `score_id` tinyint(4) DEFAULT NULL,
  `Student_id` tinyint(4) DEFAULT NULL,
  `marks` tinyint(4) DEFAULT NULL,
  `sub_id` tinyint(4) DEFAULT NULL,
  `teacher` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Second_2NF_2`
--

LOCK TABLES `Second_2NF_2` WRITE;
/*!40000 ALTER TABLE `Second_2NF_2` DISABLE KEYS */;
INSERT INTO `Second_2NF_2` VALUES (10,NULL,NULL,NULL,'pune'),(11,NULL,NULL,NULL,'Benguluru'),(12,NULL,NULL,NULL,'Delhi'),(13,NULL,NULL,NULL,'Chennai');
/*!40000 ALTER TABLE `Second_2NF_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Seond_1NF`
--

DROP TABLE IF EXISTS `Seond_1NF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Seond_1NF` (
  `EmployeeID` int(11) DEFAULT NULL,
  `EmployeeName` varchar(80) DEFAULT NULL,
  `PhoneNumber` bigint(20) DEFAULT NULL,
  `Salary` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Seond_1NF`
--

LOCK TABLES `Seond_1NF` WRITE;
/*!40000 ALTER TABLE `Seond_1NF` DISABLE KEYS */;
/*!40000 ALTER TABLE `Seond_1NF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Submissions`
--

DROP TABLE IF EXISTS `Submissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Submissions` (
  `sub_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Submissions`
--

LOCK TABLES `Submissions` WRITE;
/*!40000 ALTER TABLE `Submissions` DISABLE KEYS */;
INSERT INTO `Submissions` VALUES (1,NULL),(2,NULL),(1,NULL),(12,NULL),(3,1),(5,2),(3,1),(4,1),(9,1),(10,2),(6,7);
/*!40000 ALTER TABLE `Submissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TestLastUpdate`
--

DROP TABLE IF EXISTS `TestLastUpdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TestLastUpdate` (
  `ID` int(11) DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `LastUpdate` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='Last Update';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TestLastUpdate`
--

LOCK TABLES `TestLastUpdate` WRITE;
/*!40000 ALTER TABLE `TestLastUpdate` DISABLE KEYS */;
INSERT INTO `TestLastUpdate` VALUES (1,'tmp','No:11','2022-04-11 11:00:38');
/*!40000 ALTER TABLE `TestLastUpdate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Third_NF`
--

DROP TABLE IF EXISTS `Third_NF`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Third_NF` (
  `score_id` tinyint(4) DEFAULT NULL,
  `studi_id` tinyint(4) DEFAULT NULL,
  `sub_id` tinyint(4) DEFAULT NULL,
  `marks` tinyint(4) DEFAULT NULL,
  `exam_name` varchar(20) DEFAULT NULL,
  `total_marks` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Third_NF`
--

LOCK TABLES `Third_NF` WRITE;
/*!40000 ALTER TABLE `Third_NF` DISABLE KEYS */;
INSERT INTO `Third_NF` VALUES (10,NULL,NULL,NULL,'A',NULL),(11,NULL,NULL,NULL,'B',NULL),(12,NULL,NULL,NULL,'C',NULL),(13,NULL,NULL,NULL,'D',NULL);
/*!40000 ALTER TABLE `Third_NF` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Third_NF_1`
--

DROP TABLE IF EXISTS `Third_NF_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Third_NF_1` (
  `StudentID` int(11) DEFAULT NULL,
  `StudentName` varchar(80) DEFAULT NULL,
  `SubjectID` int(11) DEFAULT NULL,
  `Address` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Third_NF_1`
--

LOCK TABLES `Third_NF_1` WRITE;
/*!40000 ALTER TABLE `Third_NF_1` DISABLE KEYS */;
INSERT INTO `Third_NF_1` VALUES (10,'A',100,'GOA'),(11,'B',101,'Chennai'),(12,'C',102,'Adyar'),(13,'D',103,'AI');
/*!40000 ALTER TABLE `Third_NF_1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Third_NF_2`
--

DROP TABLE IF EXISTS `Third_NF_2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Third_NF_2` (
  `SubjectID` int(11) DEFAULT NULL,
  `Subject` varchar(80) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Third_NF_2`
--

LOCK TABLES `Third_NF_2` WRITE;
/*!40000 ALTER TABLE `Third_NF_2` DISABLE KEYS */;
INSERT INTO `Third_NF_2` VALUES (100,'GOA'),(101,'Chennai'),(102,'Adyar'),(103,'AI');
/*!40000 ALTER TABLE `Third_NF_2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `TransposeTable`
--

DROP TABLE IF EXISTS `TransposeTable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `TransposeTable` (
  `id` tinyint(4) DEFAULT NULL,
  `month` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `TransposeTable`
--

LOCK TABLES `TransposeTable` WRITE;
/*!40000 ALTER TABLE `TransposeTable` DISABLE KEYS */;
/*!40000 ALTER TABLE `TransposeTable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Warehouse`
--

DROP TABLE IF EXISTS `Warehouse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Warehouse` (
  `name` varchar(50) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `units` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Warehouse`
--

LOCK TABLES `Warehouse` WRITE;
/*!40000 ALTER TABLE `Warehouse` DISABLE KEYS */;
INSERT INTO `Warehouse` VALUES ('LCHouse1',1,1),('LCHouse1',2,10),('LCHouse1',3,5),('LCHouse2',1,2),('LCHouse2',2,2),('LCHouse3',4,1);
/*!40000 ALTER TABLE `Warehouse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Wheather`
--

DROP TABLE IF EXISTS `Wheather`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Wheather` (
  `Temp` varchar(250) DEFAULT NULL,
  `Wind` varchar(250) DEFAULT NULL,
  `Event` varchar(10) DEFAULT 'HOT'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Wheather`
--

LOCK TABLES `Wheather` WRITE;
/*!40000 ALTER TABLE `Wheather` DISABLE KEYS */;
INSERT INTO `Wheather` VALUES ('32','6','Rain'),('35','7','Sunny'),('28','2','Snow'),('24','7','Snow'),('32','4','Rain'),('31','2','Sunny');
/*!40000 ALTER TABLE `Wheather` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Wheathertmp`
--

DROP TABLE IF EXISTS `Wheathertmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Wheathertmp` (
  `Temp` varchar(250) DEFAULT NULL,
  `Wind` varchar(250) DEFAULT NULL,
  `Event` varchar(10) DEFAULT 'HOT'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Wheathertmp`
--

LOCK TABLES `Wheathertmp` WRITE;
/*!40000 ALTER TABLE `Wheathertmp` DISABLE KEYS */;
/*!40000 ALTER TABLE `Wheathertmp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accDetails`
--

DROP TABLE IF EXISTS `accDetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accDetails` (
  `id` tinyint(3) unsigned DEFAULT NULL,
  `sal` mediumint(8) unsigned DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accDetails`
--

LOCK TABLES `accDetails` WRITE;
/*!40000 ALTER TABLE `accDetails` DISABLE KEYS */;
INSERT INTO `accDetails` VALUES (1,600,'Rad1'),(2,200,'Rad2'),(3,300,'Rad3');
/*!40000 ALTER TABLE `accDetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `amazon_employees`
--

DROP TABLE IF EXISTS `amazon_employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `amazon_employees` (
  `emp_id` int(11) DEFAULT NULL,
  `emp_name` varchar(20) DEFAULT NULL,
  `dept_id` int(11) DEFAULT NULL,
  `salary` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `amazon_employees`
--

LOCK TABLES `amazon_employees` WRITE;
/*!40000 ALTER TABLE `amazon_employees` DISABLE KEYS */;
INSERT INTO `amazon_employees` VALUES (1,'Shashank',100,10000),(2,'Rahul',100,20000),(3,'Amit',101,15000),(4,'Mohit',101,17000),(5,'Nikhil',102,30000);
/*!40000 ALTER TABLE `amazon_employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `amazon_sales_data`
--

DROP TABLE IF EXISTS `amazon_sales_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `amazon_sales_data` (
  `sales_data` date DEFAULT NULL,
  `sales_amount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `amazon_sales_data`
--

LOCK TABLES `amazon_sales_data` WRITE;
/*!40000 ALTER TABLE `amazon_sales_data` DISABLE KEYS */;
INSERT INTO `amazon_sales_data` VALUES ('2022-08-21',500),('2022-08-22',600),('2022-08-19',300),('2022-08-18',200),('2022-08-25',800);
/*!40000 ALTER TABLE `amazon_sales_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bankaccounts`
--

DROP TABLE IF EXISTS `bankaccounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bankaccounts` (
  `accountno` varchar(20) NOT NULL,
  `funds` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`accountno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bankaccounts`
--

LOCK TABLES `bankaccounts` WRITE;
/*!40000 ALTER TABLE `bankaccounts` DISABLE KEYS */;
INSERT INTO `bankaccounts` VALUES ('ACC1',900.00),('ACC2',1100.00);
/*!40000 ALTER TABLE `bankaccounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bird`
--

DROP TABLE IF EXISTS `bird`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bird` (
  `bird_id` tinyint(4) NOT NULL COMMENT 'Changes in bird_id data type',
  `species` varchar(300) DEFAULT NULL COMMENT 'You can include genus, but never subspecies.',
  PRIMARY KEY (`bird_id`),
  KEY `idx_species` (`species`) COMMENT 'We must search on species often.'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='This table was inaugurated on February 10th.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bird`
--

LOCK TABLES `bird` WRITE;
/*!40000 ALTER TABLE `bird` DISABLE KEYS */;
/*!40000 ALTER TABLE `bird` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `car`
--

DROP TABLE IF EXISTS `car`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `car` (
  `car_id` int(10) unsigned NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `price` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`car_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `car`
--

LOCK TABLES `car` WRITE;
/*!40000 ALTER TABLE `car` DISABLE KEYS */;
INSERT INTO `car` VALUES (3,'second',3300.00),(4,NULL,1.00);
/*!40000 ALTER TABLE `car` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cinema`
--

DROP TABLE IF EXISTS `cinema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cinema` (
  `seat_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `free` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`seat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cinema`
--

LOCK TABLES `cinema` WRITE;
/*!40000 ALTER TABLE `cinema` DISABLE KEYS */;
INSERT INTO `cinema` VALUES (1,1),(2,0),(3,1),(4,1);
/*!40000 ALTER TABLE `cinema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comp_dtls`
--

DROP TABLE IF EXISTS `comp_dtls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comp_dtls` (
  `cmpId` char(5) NOT NULL,
  `cmpName` varchar(20) NOT NULL,
  `cmpCountry` varchar(20) NOT NULL,
  PRIMARY KEY (`cmpId`),
  CONSTRAINT `ck_country_cmp` CHECK (`cmpCountry` in ('india','usa','japan','uk'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comp_dtls`
--

LOCK TABLES `comp_dtls` WRITE;
/*!40000 ALTER TABLE `comp_dtls` DISABLE KEYS */;
INSERT INTO `comp_dtls` VALUES ('cmp01','sony','japan'),('cmp02','wipro','india'),('cmp03','Philips','india'),('cmp04','semantic','usa');
/*!40000 ALTER TABLE `comp_dtls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cust`
--

DROP TABLE IF EXISTS `cust`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cust` (
  `cid` char(3) DEFAULT NULL,
  `cname` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cust`
--

LOCK TABLES `cust` WRITE;
/*!40000 ALTER TABLE `cust` DISABLE KEYS */;
INSERT INTO `cust` VALUES ('c00','radee'),('c01','radee1');
/*!40000 ALTER TABLE `cust` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer` (
  `Cno` int(2) DEFAULT NULL,
  `Cname` varchar(20) DEFAULT NULL,
  `City` varchar(10) DEFAULT 'Hyderabad'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'kiran','Hyderabad'),(2,'Madhu','Hyderabad'),(3,'dinesh',NULL),(4,'john','Texas'),(NULL,'Radee','Hyderabad');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_email` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Shashank','abc@gmail.com'),(2,'Rahul','aaa@gmail.com'),(3,'Ajay','klm@gmail.com'),(4,'Nitin','poc@gmail.com'),(5,'Naveen','mnc@gmail.com');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `dept_id` int(11) DEFAULT NULL,
  `dept_name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES (100,'Software'),(101,'HR'),(102,'IT'),(103,'Finance');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dept`
--

DROP TABLE IF EXISTS `dept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dept` (
  `dno` tinyint(4) DEFAULT NULL,
  `dname` varchar(20) DEFAULT NULL,
  `loc` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dept`
--

LOCK TABLES `dept` WRITE;
/*!40000 ALTER TABLE `dept` DISABLE KEYS */;
INSERT INTO `dept` VALUES (10,'Productions','Hyderabad'),(20,'Sales','Hyderabad'),(30,'Finance','Chennai'),(40,'Developer','Banglore');
/*!40000 ALTER TABLE `dept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dept123`
--

DROP TABLE IF EXISTS `dept123`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dept123` (
  `deptno` tinyint(3) NOT NULL,
  PRIMARY KEY (`deptno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dept123`
--

LOCK TABLES `dept123` WRITE;
/*!40000 ALTER TABLE `dept123` DISABLE KEYS */;
/*!40000 ALTER TABLE `dept123` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emp`
--

DROP TABLE IF EXISTS `emp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emp` (
  `eid` tinyint(4) DEFAULT NULL,
  `ename` varchar(20) DEFAULT NULL,
  `sal` int(11) DEFAULT NULL,
  `dno` mediumint(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emp`
--

LOCK TABLES `emp` WRITE;
/*!40000 ALTER TABLE `emp` DISABLE KEYS */;
INSERT INTO `emp` VALUES (5,'C',1000,NULL),(6,'S',1300,NULL),(7,'D',2300,NULL),(8,'X',1200,NULL),(9,'B',2200,NULL),(1,'A',2000,10),(2,'X',1400,10),(3,'A',3500,30),(4,'Z',500,10),(10,'a',5000,30),(11,'b',505,30);
/*!40000 ALTER TABLE `emp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emp_info`
--

DROP TABLE IF EXISTS `emp_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emp_info` (
  `eid` tinyint(4) DEFAULT NULL,
  `ename` varchar(20) DEFAULT NULL,
  `sal` int(11) DEFAULT NULL,
  `jdate` date DEFAULT NULL,
  `desg` varchar(20) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emp_info`
--

LOCK TABLES `emp_info` WRITE;
/*!40000 ALTER TABLE `emp_info` DISABLE KEYS */;
INSERT INTO `emp_info` VALUES (111,'AB',111,'2023-04-14','developer','M'),(111,'AB',111,'2023-05-14','developer','M'),(112,'BC',141,'2021-11-13','Senior Developer','F'),(55,'aa',12,NULL,'salesman',NULL),(112,'BC',141,'0002-04-20','Senior Developer','M'),(113,'CD',221,'2022-04-20','developer','F');
/*!40000 ALTER TABLE `emp_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emp_info_child`
--

DROP TABLE IF EXISTS `emp_info_child`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emp_info_child` (
  `eid` tinyint(4) DEFAULT NULL,
  `ename` varchar(20) DEFAULT NULL,
  `sal` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emp_info_child`
--

LOCK TABLES `emp_info_child` WRITE;
/*!40000 ALTER TABLE `emp_info_child` DISABLE KEYS */;
INSERT INTO `emp_info_child` VALUES (111,'AB',111),(111,'AB',111),(112,'BC',141),(112,'BC',141),(113,'CD',221);
/*!40000 ALTER TABLE `emp_info_child` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emp_mgr`
--

DROP TABLE IF EXISTS `emp_mgr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emp_mgr` (
  `eid` tinyint(4) DEFAULT NULL,
  `ename` varchar(20) DEFAULT NULL,
  `sal` int(11) DEFAULT NULL,
  `dno` mediumint(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emp_mgr`
--

LOCK TABLES `emp_mgr` WRITE;
/*!40000 ALTER TABLE `emp_mgr` DISABLE KEYS */;
INSERT INTO `emp_mgr` VALUES (3,'A',3400,30),(10,'V',5000,30),(10,'V',5000,30),(11,'VV',5000,30);
/*!40000 ALTER TABLE `emp_mgr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emp_mgr1`
--

DROP TABLE IF EXISTS `emp_mgr1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emp_mgr1` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `manager_id` int(11) DEFAULT NULL,
  `designation` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emp_mgr1`
--

LOCK TABLES `emp_mgr1` WRITE;
/*!40000 ALTER TABLE `emp_mgr1` DISABLE KEYS */;
INSERT INTO `emp_mgr1` VALUES (1,'Shripath',NULL,'CEO'),(2,'Satya',5,'SDE'),(3,'Jia',5,'DA'),(4,'David',5,'DS'),(5,'Michael',7,'Manager'),(6,'Arvind',7,'Architect'),(7,'Asha',1,'CTO'),(8,'Maryam',1,'Manager');
/*!40000 ALTER TABLE `emp_mgr1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employees`
--

DROP TABLE IF EXISTS `employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `fname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `hired` date NOT NULL DEFAULT '1970-01-01',
  `separated` date NOT NULL DEFAULT '9999-12-31',
  `job_code` int(11) NOT NULL,
  `store_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
 PARTITION BY RANGE (`store_id`)
(PARTITION `p0` VALUES LESS THAN (6) ENGINE = InnoDB,
 PARTITION `p1` VALUES LESS THAN (11) ENGINE = InnoDB,
 PARTITION `p2` VALUES LESS THAN (16) ENGINE = InnoDB,
 PARTITION `p3` VALUES LESS THAN MAXVALUE ENGINE = InnoDB);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employees`
--

LOCK TABLES `employees` WRITE;
/*!40000 ALTER TABLE `employees` DISABLE KEYS */;
/*!40000 ALTER TABLE `employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `enum`
--

DROP TABLE IF EXISTS `enum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `enum` (
  `e` enum('yes','no') NOT NULL,
  `enull` enum('x','y','z') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `enum`
--

LOCK TABLES `enum` WRITE;
/*!40000 ALTER TABLE `enum` DISABLE KEYS */;
/*!40000 ALTER TABLE `enum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `firsttable`
--

DROP TABLE IF EXISTS `firsttable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `firsttable` (
  `id` tinyint(4) DEFAULT NULL,
  `marks` decimal(10,0) DEFAULT NULL,
  `marks1` float DEFAULT NULL,
  `marks2` double DEFAULT NULL,
  `check1` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `firsttable`
--

LOCK TABLES `firsttable` WRITE;
/*!40000 ALTER TABLE `firsttable` DISABLE KEYS */;
/*!40000 ALTER TABLE `firsttable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fruit_baskets`
--

DROP TABLE IF EXISTS `fruit_baskets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fruit_baskets` (
  `sale_date` date DEFAULT NULL,
  `fruit` enum('apples','oranges') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fruit_baskets`
--

LOCK TABLES `fruit_baskets` WRITE;
/*!40000 ALTER TABLE `fruit_baskets` DISABLE KEYS */;
/*!40000 ALTER TABLE `fruit_baskets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice_line_items`
--

DROP TABLE IF EXISTS `invoice_line_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_line_items` (
  `LineNum` smallint(5) unsigned NOT NULL,
  `InvoiceNum` int(10) unsigned NOT NULL,
  PRIMARY KEY (`InvoiceNum`,`LineNum`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice_line_items`
--

LOCK TABLES `invoice_line_items` WRITE;
/*!40000 ALTER TABLE `invoice_line_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoice_line_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iodku`
--

DROP TABLE IF EXISTS `iodku`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iodku` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  `misc` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iodku`
--

LOCK TABLES `iodku` WRITE;
/*!40000 ALTER TABLE `iodku` DISABLE KEYS */;
INSERT INTO `iodku` VALUES (1,'Leslie',100),(2,'Sally',100),(3,'Dana',100),(101,'Kite',101),(102,'K',102),(103,'Radee123',123);
/*!40000 ALTER TABLE `iodku` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iodku1`
--

DROP TABLE IF EXISTS `iodku1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iodku1` (
  `id` int(10) unsigned NOT NULL DEFAULT 0,
  `name` varchar(10) DEFAULT NULL,
  `misc` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iodku1`
--

LOCK TABLES `iodku1` WRITE;
/*!40000 ALTER TABLE `iodku1` DISABLE KEYS */;
INSERT INTO `iodku1` VALUES (1,'Leslie',123),(2,'Sally',3333);
/*!40000 ALTER TABLE `iodku1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iodkuchild`
--

DROP TABLE IF EXISTS `iodkuchild`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iodkuchild` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(99) NOT NULL,
  `misc` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iodkuchild`
--

LOCK TABLES `iodkuchild` WRITE;
/*!40000 ALTER TABLE `iodkuchild` DISABLE KEYS */;
INSERT INTO `iodkuchild` VALUES (1,'Leslie',123),(2,'Sally',3333),(3,'Dana',789);
/*!40000 ALTER TABLE `iodkuchild` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `keychild`
--

DROP TABLE IF EXISTS `keychild`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `keychild` (
  `Deptid` tinyint(4) DEFAULT NULL COMMENT 'PK',
  `Name` varchar(10) DEFAULT NULL,
  `Address` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `keychild`
--

LOCK TABLES `keychild` WRITE;
/*!40000 ALTER TABLE `keychild` DISABLE KEYS */;
/*!40000 ALTER TABLE `keychild` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `keyparent`
--

DROP TABLE IF EXISTS `keyparent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `keyparent` (
  `id` tinyint(4) DEFAULT NULL COMMENT 'PK',
  `Rollno` mediumint(9) DEFAULT NULL COMMENT 'AK',
  `Name` varchar(10) DEFAULT NULL,
  `EnrollNo` tinyint(4) DEFAULT NULL COMMENT 'AK',
  `Address` varchar(10) DEFAULT NULL,
  `Deptid` tinyint(4) DEFAULT NULL COMMENT 'FK'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `keyparent`
--

LOCK TABLES `keyparent` WRITE;
/*!40000 ALTER TABLE `keyparent` DISABLE KEYS */;
/*!40000 ALTER TABLE `keyparent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mergeproducts`
--

DROP TABLE IF EXISTS `mergeproducts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mergeproducts` (
  `productid` int(11) NOT NULL,
  `productname` varchar(50) NOT NULL,
  `cost` int(11) NOT NULL,
  PRIMARY KEY (`productid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mergeproducts`
--

LOCK TABLES `mergeproducts` WRITE;
/*!40000 ALTER TABLE `mergeproducts` DISABLE KEYS */;
INSERT INTO `mergeproducts` VALUES (1,'parle G',100),(2,'butter',200),(3,'pista',300);
/*!40000 ALTER TABLE `mergeproducts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mergeproducts_child`
--

DROP TABLE IF EXISTS `mergeproducts_child`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mergeproducts_child` (
  `productid` int(11) NOT NULL,
  `productname` varchar(50) NOT NULL,
  `cost` int(11) NOT NULL,
  PRIMARY KEY (`productid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mergeproducts_child`
--

LOCK TABLES `mergeproducts_child` WRITE;
/*!40000 ALTER TABLE `mergeproducts_child` DISABLE KEYS */;
INSERT INTO `mergeproducts_child` VALUES (1,'parle G',100),(2,'butter',350),(3,'pista',450),(4,'dark',500),(5,'white',600);
/*!40000 ALTER TABLE `mergeproducts_child` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `my_numbers`
--

DROP TABLE IF EXISTS `my_numbers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `my_numbers` (
  `num` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `my_numbers`
--

LOCK TABLES `my_numbers` WRITE;
/*!40000 ALTER TABLE `my_numbers` DISABLE KEYS */;
INSERT INTO `my_numbers` VALUES (8),(8),(3),(3),(1),(4),(5),(6);
/*!40000 ALTER TABLE `my_numbers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `normalization`
--

DROP TABLE IF EXISTS `normalization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `normalization` (
  `s_id` tinyint(3) unsigned DEFAULT NULL,
  `s_name` varchar(10) DEFAULT NULL,
  `s_credits` tinyint(3) unsigned DEFAULT NULL,
  `dept_name` varchar(10) DEFAULT NULL,
  `building` varchar(10) DEFAULT NULL,
  `room_no` tinyint(3) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `normalization`
--

LOCK TABLES `normalization` WRITE;
/*!40000 ALTER TABLE `normalization` DISABLE KEYS */;
INSERT INTO `normalization` VALUES (1,'Rahul',5,'cse','B1',101),(2,'jiya',8,'cse','B1',101),(3,'jenny',9,'fash','B2',201),(4,'payal',9,'fash','B2',201),(5,'ankur',7,'civil','B1',110),(6,'aakash',7,'ece','B1',115),(7,'vakash',8,'civil','B1',110),(8,'Tahul',7,'cse','B1',101);
/*!40000 ALTER TABLE `normalization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `one`
--

DROP TABLE IF EXISTS `one`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `one` (
  `id` int(11) DEFAULT NULL,
  `acc` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `one`
--

LOCK TABLES `one` WRITE;
/*!40000 ALTER TABLE `one` DISABLE KEYS */;
INSERT INTO `one` VALUES (1,'one'),(2,'two'),(3,'three');
/*!40000 ALTER TABLE `one` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (101,1,550,'Delivered'),(102,2,350,'Delivered'),(103,1,220,'Cancelled'),(104,3,660,'Delivered'),(105,3,300,'Delivered');
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `owners`
--

DROP TABLE IF EXISTS `owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `owners` (
  `owner_id` tinyint(4) NOT NULL AUTO_INCREMENT,
  `owner` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`owner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `owners`
--

LOCK TABLES `owners` WRITE;
/*!40000 ALTER TABLE `owners` DISABLE KEYS */;
INSERT INTO `owners` VALUES (1,'Ben'),(2,'Jim'),(3,'Harry'),(6,'John'),(9,'Ellie');
/*!40000 ALTER TABLE `owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pPerson`
--

DROP TABLE IF EXISTS `pPerson`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pPerson` (
  `Id` int(11) DEFAULT NULL,
  `Email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pPerson`
--

LOCK TABLES `pPerson` WRITE;
/*!40000 ALTER TABLE `pPerson` DISABLE KEYS */;
INSERT INTO `pPerson` VALUES (1,'john@example.com'),(2,'bob@example.com');
/*!40000 ALTER TABLE `pPerson` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pScores`
--

DROP TABLE IF EXISTS `pScores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pScores` (
  `player_name` varchar(20) DEFAULT NULL,
  `gender` varchar(1) DEFAULT NULL,
  `day` date DEFAULT NULL,
  `score_points` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pScores`
--

LOCK TABLES `pScores` WRITE;
/*!40000 ALTER TABLE `pScores` DISABLE KEYS */;
INSERT INTO `pScores` VALUES ('Aron','F','2020-01-01',17),('Alice','F','2020-01-07',23),('Bajrang','M','2020-01-07',7),('Khali','M','2019-12-25',11),('Slaman','M','2019-12-30',13),('Joe','M','2019-12-31',3),('Jose','M','2019-12-18',2),('Priya','F','2019-12-31',23),('Priyanka','F','2019-12-30',17);
/*!40000 ALTER TABLE `pScores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `partitioning_employees`
--

DROP TABLE IF EXISTS `partitioning_employees`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `partitioning_employees` (
  `id` int(11) NOT NULL,
  `fname` varchar(30) DEFAULT NULL,
  `lname` varchar(30) DEFAULT NULL,
  `hired` date NOT NULL DEFAULT '1970-01-01',
  `separated` date NOT NULL DEFAULT '9999-12-31',
  `job_code` int(11) NOT NULL,
  `store_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
 PARTITION BY HASH (`store_id`)
PARTITIONS 4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `partitioning_employees`
--

LOCK TABLES `partitioning_employees` WRITE;
/*!40000 ALTER TABLE `partitioning_employees` DISABLE KEYS */;
/*!40000 ALTER TABLE `partitioning_employees` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pdcinema`
--

DROP TABLE IF EXISTS `pdcinema`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pdcinema` (
  `id` int(11) DEFAULT NULL,
  `movie` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `rating` decimal(10,0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pdcinema`
--

LOCK TABLES `pdcinema` WRITE;
/*!40000 ALTER TABLE `pdcinema` DISABLE KEYS */;
INSERT INTO `pdcinema` VALUES (1,'War','great 3D',9),(2,'Science','fiction',9),(3,'irish','boring',6),(4,'Ice song','Fantacy',9),(5,'House card','Interesting',9);
/*!40000 ALTER TABLE `pdcinema` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `people`
--

DROP TABLE IF EXISTS `people`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `people` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `gender` char(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `people`
--

LOCK TABLES `people` WRITE;
/*!40000 ALTER TABLE `people` DISABLE KEYS */;
INSERT INTO `people` VALUES (1,'Kathy','f'),(3,'Paul','m'),(4,'Kim','f');
/*!40000 ALTER TABLE `people` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pets`
--

DROP TABLE IF EXISTS `pets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ownerId` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `color` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pets`
--

LOCK TABLES `pets` WRITE;
/*!40000 ALTER TABLE `pets` DISABLE KEYS */;
INSERT INTO `pets` VALUES (1,1,'Rover','beige'),(4,1,'Rover2','white');
/*!40000 ALTER TABLE `pets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `problemsolving1`
--

DROP TABLE IF EXISTS `problemsolving1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `problemsolving1` (
  `a` tinyint(4) DEFAULT NULL,
  `b` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `problemsolving1`
--

LOCK TABLES `problemsolving1` WRITE;
/*!40000 ALTER TABLE `problemsolving1` DISABLE KEYS */;
INSERT INTO `problemsolving1` VALUES (1,2),(3,2),(2,4),(2,1),(5,6),(4,2);
/*!40000 ALTER TABLE `problemsolving1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `problemsolving2_table1`
--

DROP TABLE IF EXISTS `problemsolving2_table1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `problemsolving2_table1` (
  `colA` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `problemsolving2_table1`
--

LOCK TABLES `problemsolving2_table1` WRITE;
/*!40000 ALTER TABLE `problemsolving2_table1` DISABLE KEYS */;
INSERT INTO `problemsolving2_table1` VALUES (1),(2),(1),(5),(NULL),(NULL);
/*!40000 ALTER TABLE `problemsolving2_table1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `problemsolving2_table2`
--

DROP TABLE IF EXISTS `problemsolving2_table2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `problemsolving2_table2` (
  `colB` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `problemsolving2_table2`
--

LOCK TABLES `problemsolving2_table2` WRITE;
/*!40000 ALTER TABLE `problemsolving2_table2` DISABLE KEYS */;
INSERT INTO `problemsolving2_table2` VALUES (NULL),(2),(5),(5);
/*!40000 ALTER TABLE `problemsolving2_table2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prod_DTLS`
--

DROP TABLE IF EXISTS `prod_DTLS`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prod_DTLS` (
  `pid` char(4) NOT NULL,
  `pname` varchar(20) NOT NULL,
  `cost` float(7,2) DEFAULT NULL,
  `mfg` date DEFAULT NULL,
  `warrenty` varchar(10) DEFAULT NULL,
  `cmpId` char(5) DEFAULT NULL,
  PRIMARY KEY (`pid`),
  KEY `fk` (`cmpId`),
  CONSTRAINT `fk` FOREIGN KEY (`cmpId`) REFERENCES `comp_dtls` (`cmpId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prod_DTLS`
--

LOCK TABLES `prod_DTLS` WRITE;
/*!40000 ALTER TABLE `prod_DTLS` DISABLE KEYS */;
/*!40000 ALTER TABLE `prod_DTLS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ps1_orders`
--

DROP TABLE IF EXISTS `ps1_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ps1_orders` (
  `order_number` int(11) DEFAULT NULL,
  `customer_number` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ps1_orders`
--

LOCK TABLES `ps1_orders` WRITE;
/*!40000 ALTER TABLE `ps1_orders` DISABLE KEYS */;
INSERT INTO `ps1_orders` VALUES (1,1),(2,2),(3,3),(4,3);
/*!40000 ALTER TABLE `ps1_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ps3`
--

DROP TABLE IF EXISTS `ps3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ps3` (
  `id` tinyint(4) DEFAULT NULL,
  `subject` varchar(50) DEFAULT NULL,
  `marks` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ps3`
--

LOCK TABLES `ps3` WRITE;
/*!40000 ALTER TABLE `ps3` DISABLE KEYS */;
INSERT INTO `ps3` VALUES (11,'english',88),(11,'tamil',66),(11,'maths',85),(12,'english',81),(12,'tamil',71),(12,'maths',100),(13,'english',10);
/*!40000 ALTER TABLE `ps3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psCustomer`
--

DROP TABLE IF EXISTS `psCustomer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psCustomer` (
  `customer_id` int(11) DEFAULT NULL,
  `product_key` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psCustomer`
--

LOCK TABLES `psCustomer` WRITE;
/*!40000 ALTER TABLE `psCustomer` DISABLE KEYS */;
INSERT INTO `psCustomer` VALUES (1,5),(2,6),(3,5),(3,6),(1,6);
/*!40000 ALTER TABLE `psCustomer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psEmployee`
--

DROP TABLE IF EXISTS `psEmployee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psEmployee` (
  `Id` int(11) DEFAULT NULL,
  `Salary` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psEmployee`
--

LOCK TABLES `psEmployee` WRITE;
/*!40000 ALTER TABLE `psEmployee` DISABLE KEYS */;
INSERT INTO `psEmployee` VALUES (1,100),(2,200),(3,300);
/*!40000 ALTER TABLE `psEmployee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psLogins`
--

DROP TABLE IF EXISTS `psLogins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psLogins` (
  `user_id` int(11) DEFAULT NULL,
  `time_stamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psLogins`
--

LOCK TABLES `psLogins` WRITE;
/*!40000 ALTER TABLE `psLogins` DISABLE KEYS */;
INSERT INTO `psLogins` VALUES (6,'2020-06-30 09:36:07'),(6,'2021-04-21 08:36:06'),(6,'2019-03-06 18:48:15'),(8,'2020-01-31 23:40:53'),(8,'2020-12-29 19:16:50'),(2,'2020-01-15 21:19:50'),(2,'2019-08-25 02:29:08'),(14,'2019-07-14 03:30:00'),(14,'2021-01-06 06:29:59');
/*!40000 ALTER TABLE `psLogins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psProduct`
--

DROP TABLE IF EXISTS `psProduct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psProduct` (
  `product_key` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psProduct`
--

LOCK TABLES `psProduct` WRITE;
/*!40000 ALTER TABLE `psProduct` DISABLE KEYS */;
INSERT INTO `psProduct` VALUES (5),(6);
/*!40000 ALTER TABLE `psProduct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `psRelations`
--

DROP TABLE IF EXISTS `psRelations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `psRelations` (
  `user_id` int(11) DEFAULT NULL,
  `follower_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psRelations`
--

LOCK TABLES `psRelations` WRITE;
/*!40000 ALTER TABLE `psRelations` DISABLE KEYS */;
INSERT INTO `psRelations` VALUES (1,3),(2,3),(7,3),(1,4),(2,4),(7,4),(1,5),(2,6),(7,5);
/*!40000 ALTER TABLE `psRelations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ps_customers`
--

DROP TABLE IF EXISTS `ps_customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ps_customers` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(100) DEFAULT NULL,
  `customer_email` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ps_customers`
--

LOCK TABLES `ps_customers` WRITE;
/*!40000 ALTER TABLE `ps_customers` DISABLE KEYS */;
INSERT INTO `ps_customers` VALUES (1,'Shashank','abc@gmail.com'),(2,'Rahul','aaa@gmail.com'),(3,'Ajay','klm@gmail.com'),(4,'Nitin','poc@gmail.com'),(5,'Naveen','mnc@gmail.com');
/*!40000 ALTER TABLE `ps_customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ps_orders`
--

DROP TABLE IF EXISTS `ps_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ps_orders` (
  `order_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `amount` float DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ps_orders`
--

LOCK TABLES `ps_orders` WRITE;
/*!40000 ALTER TABLE `ps_orders` DISABLE KEYS */;
INSERT INTO `ps_orders` VALUES (101,1,550,'Delivered'),(102,2,350,'Delivered'),(103,1,220,'Cancelled'),(104,3,660,'Delivered'),(105,3,300,'Delivered');
/*!40000 ALTER TABLE `ps_orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `regualr_emp`
--

DROP TABLE IF EXISTS `regualr_emp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `regualr_emp` (
  `eid` tinyint(4) DEFAULT NULL,
  `ename` varchar(20) DEFAULT NULL,
  `sal` int(11) DEFAULT NULL,
  `dno` mediumint(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `regualr_emp`
--

LOCK TABLES `regualr_emp` WRITE;
/*!40000 ALTER TABLE `regualr_emp` DISABLE KEYS */;
INSERT INTO `regualr_emp` VALUES (5,'P@ssword@29027',1000,NULL),(6,'Sdsf',1300,NULL),(7,'Dine',2300,NULL),(8,'Xavds',1200,NULL),(9,'Balaj',2200,NULL),(1,'Ask',2000,10),(2,'Xadf',1200,10),(3,'Aasdf',3500,30),(4,'prade',5000,10),(10,'Vivvv',5000,30),(10,'Vivvv',5000,30),(10,'Vivvv',5000,30),(100,'Pradeep',100000,12);
/*!40000 ALTER TABLE `regualr_emp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sales_entity`
--

DROP TABLE IF EXISTS `sales_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sales_entity` (
  `sales_data` date DEFAULT NULL,
  `month_attribute` tinyint(4) DEFAULT NULL,
  `sales_amount` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_entity`
--

LOCK TABLES `sales_entity` WRITE;
/*!40000 ALTER TABLE `sales_entity` DISABLE KEYS */;
INSERT INTO `sales_entity` VALUES ('2022-08-21',NULL,500),('2022-08-22',NULL,600),('2022-08-19',NULL,300),('2022-08-18',NULL,200),('2022-08-25',NULL,800);
/*!40000 ALTER TABLE `sales_entity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `sales_informations`
--

DROP TABLE IF EXISTS `sales_informations`;
/*!50001 DROP VIEW IF EXISTS `sales_informations`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `sales_informations` AS SELECT
 1 AS `dno`,
  1 AS `dname`,
  1 AS `loc` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `spSales`
--

DROP TABLE IF EXISTS `spSales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spSales` (
  `sale_date` date DEFAULT NULL,
  `fruit` enum('apples','oranges') DEFAULT NULL,
  `sold_num` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spSales`
--

LOCK TABLES `spSales` WRITE;
/*!40000 ALTER TABLE `spSales` DISABLE KEYS */;
INSERT INTO `spSales` VALUES ('2020-05-01','apples',10),('2020-05-01','oranges',8),('2020-05-02','apples',15),('2020-05-02','oranges',15),('2020-05-03','apples',20),('2020-05-03','oranges',0),('2020-05-04','apples',15),('2020-05-04','oranges',16);
/*!40000 ALTER TABLE `spSales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stack`
--

DROP TABLE IF EXISTS `stack`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stack` (
  `id_user` int(11) NOT NULL,
  `mod_id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `submit_date` datetime NOT NULL,
  `newcolumn` date NOT NULL,
  `newcolumn1` date DEFAULT NULL,
  `newcolumn11` date DEFAULT NULL,
  `newcolumn2` date DEFAULT NULL,
  `newcolumn12` date DEFAULT NULL,
  `newcolumn333` time DEFAULT NULL,
  KEY `stack_index` (`id_user`,`mod_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stack`
--

LOCK TABLES `stack` WRITE;
/*!40000 ALTER TABLE `stack` DISABLE KEYS */;
/*!40000 ALTER TABLE `stack` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stack1`
--

DROP TABLE IF EXISTS `stack1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stack1` (
  `id` int(11) DEFAULT NULL COMMENT 'You can include genus, but never subspecies.',
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stack1`
--

LOCK TABLES `stack1` WRITE;
/*!40000 ALTER TABLE `stack1` DISABLE KEYS */;
/*!40000 ALTER TABLE `stack1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stack2`
--

DROP TABLE IF EXISTS `stack2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stack2` (
  `id_user` int(11) NOT NULL,
  `mod_id` int(11) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `submit_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stack2`
--

LOCK TABLES `stack2` WRITE;
/*!40000 ALTER TABLE `stack2` DISABLE KEYS */;
/*!40000 ALTER TABLE `stack2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stack3`
--

DROP TABLE IF EXISTS `stack3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stack3` (
  `LastName` int(11) NOT NULL,
  `FirstName` varchar(66) DEFAULT NULL,
  PRIMARY KEY (`LastName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stack3`
--

LOCK TABLES `stack3` WRITE;
/*!40000 ALTER TABLE `stack3` DISABLE KEYS */;
INSERT INTO `stack3` VALUES (10,'100');
/*!40000 ALTER TABLE `stack3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stud_dtls`
--

DROP TABLE IF EXISTS `stud_dtls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stud_dtls` (
  `rno` int(2) NOT NULL,
  `sname` varchar(10) NOT NULL,
  `course` varchar(15) NOT NULL,
  `fee` int(5) NOT NULL,
  `mobile` char(10) DEFAULT NULL,
  PRIMARY KEY (`rno`),
  UNIQUE KEY `mobile` (`mobile`),
  CONSTRAINT `CONSTRAINT_1` CHECK (`rno` between 1 and 60),
  CONSTRAINT `CONSTRAINT_2` CHECK (`course` in ('oracle','sql server','unix')),
  CONSTRAINT `CONSTRAINT_3` CHECK (`fee` between 5000 and 10000)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stud_dtls`
--

LOCK TABLES `stud_dtls` WRITE;
/*!40000 ALTER TABLE `stud_dtls` DISABLE KEYS */;
INSERT INTO `stud_dtls` VALUES (1,'a','oracle',7000,'1212'),(12,'b','sql server',7000,NULL),(21,'hari','unix',9000,'1211');
/*!40000 ALTER TABLE `stud_dtls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `rno` int(2) NOT NULL,
  `sname` varchar(10) NOT NULL,
  `course` varchar(15) NOT NULL,
  `fee` int(5) NOT NULL,
  `mobile` char(10) DEFAULT NULL,
  PRIMARY KEY (`rno`),
  UNIQUE KEY `mobile` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (0,'b','java',2000,'8787878787'),(1,'a','oracle',9000,'8989898989'),(2,'x','oracle',9000,NULL),(11,'s','abc',100,NULL);
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_details`
--

DROP TABLE IF EXISTS `student_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_details` (
  `rno` int(2) NOT NULL,
  PRIMARY KEY (`rno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_details`
--

LOCK TABLES `student_details` WRITE;
/*!40000 ALTER TABLE `student_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_dtls`
--

DROP TABLE IF EXISTS `student_dtls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_dtls` (
  `rno` int(2) NOT NULL,
  `sname` varchar(20) NOT NULL,
  `course` varchar(7) NOT NULL,
  `fee` tinyint(5) DEFAULT NULL,
  `mobile` tinyint(10) DEFAULT NULL,
  PRIMARY KEY (`rno`),
  UNIQUE KEY `mobile` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_dtls`
--

LOCK TABLES `student_dtls` WRITE;
/*!40000 ALTER TABLE `student_dtls` DISABLE KEYS */;
/*!40000 ALTER TABLE `student_dtls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subproblemsolving`
--

DROP TABLE IF EXISTS `subproblemsolving`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subproblemsolving` (
  `a` tinyint(4) DEFAULT NULL,
  `b` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subproblemsolving`
--

LOCK TABLES `subproblemsolving` WRITE;
/*!40000 ALTER TABLE `subproblemsolving` DISABLE KEYS */;
/*!40000 ALTER TABLE `subproblemsolving` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `temp1`
--

DROP TABLE IF EXISTS `temp1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `temp1` (
  `empid` tinyint(4) DEFAULT NULL,
  `firstmax` tinyint(4) DEFAULT NULL,
  `secondmax` int(5) DEFAULT NULL,
  `firstmin` tinyint(4) DEFAULT NULL,
  `secondmin` bigint(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `temp1`
--

LOCK TABLES `temp1` WRITE;
/*!40000 ALTER TABLE `temp1` DISABLE KEYS */;
INSERT INTO `temp1` VALUES (1,12,11,1,2),(2,10,9,1,2);
/*!40000 ALTER TABLE `temp1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tempconsrainttable`
--

DROP TABLE IF EXISTS `tempconsrainttable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tempconsrainttable` (
  `id` tinyint(4) NOT NULL,
  `name` tinytext NOT NULL,
  `phone` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `ck` CHECK (`name` in ('radee','check','name'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tempconsrainttable`
--

LOCK TABLES `tempconsrainttable` WRITE;
/*!40000 ALTER TABLE `tempconsrainttable` DISABLE KEYS */;
/*!40000 ALTER TABLE `tempconsrainttable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmp`
--

DROP TABLE IF EXISTS `tmp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tmp` (
  `rno` int(2) NOT NULL,
  `sname` varchar(20) DEFAULT NULL,
  `course` varchar(7) DEFAULT NULL,
  `fee` tinyint(5) DEFAULT NULL,
  `mobile` tinyint(10) DEFAULT NULL,
  PRIMARY KEY (`rno`),
  UNIQUE KEY `tmpmobilepkcn` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmp`
--

LOCK TABLES `tmp` WRITE;
/*!40000 ALTER TABLE `tmp` DISABLE KEYS */;
INSERT INTO `tmp` VALUES (1,'first','sql',20,12),(2,'Sceond','SQL',12,1);
/*!40000 ALTER TABLE `tmp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmp1`
--

DROP TABLE IF EXISTS `tmp1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tmp1` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `FName` varchar(10) DEFAULT 'Rade',
  `CurrentDateUpdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `FName` (`FName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmp1`
--

LOCK TABLES `tmp1` WRITE;
/*!40000 ALTER TABLE `tmp1` DISABLE KEYS */;
/*!40000 ALTER TABLE `tmp1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmp1backup`
--

DROP TABLE IF EXISTS `tmp1backup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tmp1backup` (
  `rno` int(2) NOT NULL,
  `sname` varchar(20) DEFAULT NULL,
  `course` varchar(7) DEFAULT NULL,
  `fee` tinyint(5) DEFAULT NULL,
  `mobile` tinyint(10) DEFAULT NULL,
  PRIMARY KEY (`rno`),
  UNIQUE KEY `uq` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmp1backup`
--

LOCK TABLES `tmp1backup` WRITE;
/*!40000 ALTER TABLE `tmp1backup` DISABLE KEYS */;
INSERT INTO `tmp1backup` VALUES (1,'first','sql',20,12),(2,'Sceond','SQL',12,1);
/*!40000 ALTER TABLE `tmp1backup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmpbackup`
--

DROP TABLE IF EXISTS `tmpbackup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tmpbackup` (
  `rno` int(2) NOT NULL,
  `sname` varchar(20) DEFAULT NULL,
  `course` varchar(7) DEFAULT NULL,
  `fee` tinyint(5) DEFAULT NULL,
  `mobile` tinyint(10) DEFAULT NULL,
  PRIMARY KEY (`rno`),
  UNIQUE KEY `tmpmobilepkcn` (`mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmpbackup`
--

LOCK TABLES `tmpbackup` WRITE;
/*!40000 ALTER TABLE `tmpbackup` DISABLE KEYS */;
/*!40000 ALTER TABLE `tmpbackup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmptable1`
--

DROP TABLE IF EXISTS `tmptable1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tmptable1` (
  `empid` tinyint(4) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmptable1`
--

LOCK TABLES `tmptable1` WRITE;
/*!40000 ALTER TABLE `tmptable1` DISABLE KEYS */;
INSERT INTO `tmptable1` VALUES (1,'emp1'),(2,'emp2'),(3,'emp3');
/*!40000 ALTER TABLE `tmptable1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tmptable2`
--

DROP TABLE IF EXISTS `tmptable2`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tmptable2` (
  `id` tinyint(4) DEFAULT NULL,
  `empid` tinyint(4) DEFAULT NULL,
  `monthno` tinyint(4) DEFAULT NULL,
  `salary` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tmptable2`
--

LOCK TABLES `tmptable2` WRITE;
/*!40000 ALTER TABLE `tmptable2` DISABLE KEYS */;
INSERT INTO `tmptable2` VALUES (1,1,1,500),(2,1,2,1001),(3,1,3,NULL),(4,1,4,500),(5,1,5,400),(6,1,6,700),(7,1,7,NULL),(8,1,8,1000),(9,1,9,1000),(10,1,10,1000),(11,1,11,1000),(12,1,12,300),(1,2,1,1000),(2,2,2,1000),(3,2,3,1000),(4,2,4,1000),(5,2,5,1000),(6,2,6,200),(7,2,7,300),(8,2,8,1000),(9,2,9,400),(10,2,10,NULL);
/*!40000 ALTER TABLE `tmptable2` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tools`
--

DROP TABLE IF EXISTS `tools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tools` (
  `tool_id` int(11) NOT NULL AUTO_INCREMENT,
  `tool` varchar(30) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tool_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tools`
--

LOCK TABLES `tools` WRITE;
/*!40000 ALTER TABLE `tools` DISABLE KEYS */;
INSERT INTO `tools` VALUES (1,'Hammer',9),(2,'Pliers',1),(3,'Knife',1),(4,'Chisel',2),(5,'Hacksaw',1),(6,'Level',NULL),(7,'Wrench',NULL),(8,'Tape Measure',9),(9,'Screwdriver',NULL),(10,'Clamp',NULL);
/*!40000 ALTER TABLE `tools` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `trx_date` date DEFAULT NULL,
  `merchant_id` varchar(10) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `payment_mode` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES ('2022-04-02','m1',150,'CASH'),('2022-04-02','m1',500,'ONLINE'),('2022-04-03','m2',450,'ONLINE'),('2022-04-03','m1',100,'CASH'),('2022-04-03','m3',600,'CASH'),('2022-04-05','m5',200,'ONLINE'),('2022-04-05','m2',100,'ONLINE');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tree`
--

DROP TABLE IF EXISTS `tree`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tree` (
  `node` int(11) DEFAULT NULL,
  `parent` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tree`
--

LOCK TABLES `tree` WRITE;
/*!40000 ALTER TABLE `tree` DISABLE KEYS */;
INSERT INTO `tree` VALUES (5,8),(9,8),(4,5),(2,9),(1,5),(3,9),(8,NULL);
/*!40000 ALTER TABLE `tree` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `two`
--

DROP TABLE IF EXISTS `two`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `two` (
  `acct` varchar(25) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `ids` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `two`
--

LOCK TABLES `two` WRITE;
/*!40000 ALTER TABLE `two` DISABLE KEYS */;
INSERT INTO `two` VALUES ('one',1),('two',3),('four',4);
/*!40000 ALTER TABLE `two` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_activity`
--

DROP TABLE IF EXISTS `user_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_activity` (
  `date` date DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `activity` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_activity`
--

LOCK TABLES `user_activity` WRITE;
/*!40000 ALTER TABLE `user_activity` DISABLE KEYS */;
INSERT INTO `user_activity` VALUES ('2022-02-20',1,'abc'),('2022-02-20',2,'xyz'),('2022-02-22',1,'xyz'),('2022-02-22',3,'klm'),('2022-02-24',2,'abc'),('2022-02-24',2,'abc'),('2022-02-24',3,'abc');
/*!40000 ALTER TABLE `user_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `view_emp_mgr`
--

DROP TABLE IF EXISTS `view_emp_mgr`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `view_emp_mgr` (
  `eid` tinyint(4) DEFAULT NULL,
  `ename` varchar(20) DEFAULT NULL,
  `sal` int(11) DEFAULT NULL,
  `dno` mediumint(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `view_emp_mgr`
--

LOCK TABLES `view_emp_mgr` WRITE;
/*!40000 ALTER TABLE `view_emp_mgr` DISABLE KEYS */;
INSERT INTO `view_emp_mgr` VALUES (3,'A',3400,30),(10,'V',5000,30),(10,'V',5000,30),(10,'V',5000,30),(100,'V',5000,30);
/*!40000 ALTER TABLE `view_emp_mgr` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `view_emp_mgr_info`
--

DROP TABLE IF EXISTS `view_emp_mgr_info`;
/*!50001 DROP VIEW IF EXISTS `view_emp_mgr_info`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_emp_mgr_info` AS SELECT
 1 AS `eid`,
  1 AS `ename`,
  1 AS `sal`,
  1 AS `dno` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_finance_informations`
--

DROP TABLE IF EXISTS `view_finance_informations`;
/*!50001 DROP VIEW IF EXISTS `view_finance_informations`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_finance_informations` AS SELECT
 1 AS `eid`,
  1 AS `ename`,
  1 AS `sal`,
  1 AS `dno` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `view_sales_informations`
--

DROP TABLE IF EXISTS `view_sales_informations`;
/*!50001 DROP VIEW IF EXISTS `view_sales_informations`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_sales_informations` AS SELECT
 1 AS `dno`,
  1 AS `dname`,
  1 AS `loc` */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `vw_emp_dept_info`
--

DROP TABLE IF EXISTS `vw_emp_dept_info`;
/*!50001 DROP VIEW IF EXISTS `vw_emp_dept_info`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `vw_emp_dept_info` AS SELECT
 1 AS `ename`,
  1 AS `sal`,
  1 AS `dname`,
  1 AS `loc` */;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `sales_informations`
--

/*!50001 DROP VIEW IF EXISTS `sales_informations`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `sales_informations` AS select `dept`.`dno` AS `dno`,`dept`.`dname` AS `dname`,`dept`.`loc` AS `loc` from `dept` where `dept`.`dname` = 'Sales' */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_emp_mgr_info`
--

/*!50001 DROP VIEW IF EXISTS `view_emp_mgr_info`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_emp_mgr_info` AS select `emp`.`eid` AS `eid`,`emp`.`ename` AS `ename`,`emp`.`sal` AS `sal`,`emp`.`dno` AS `dno` from `emp` where `emp`.`dno` = 30 */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_finance_informations`
--

/*!50001 DROP VIEW IF EXISTS `view_finance_informations`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_finance_informations` AS select `e`.`eid` AS `eid`,`e`.`ename` AS `ename`,`e`.`sal` AS `sal`,`e`.`dno` AS `dno` from (`emp` `e` join `dept` `d` on(`e`.`dno` = `d`.`dno`)) where `d`.`dname` = 'Finance' */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_sales_informations`
--

/*!50001 DROP VIEW IF EXISTS `view_sales_informations`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_sales_informations` AS select `dept`.`dno` AS `dno`,`dept`.`dname` AS `dname`,`dept`.`loc` AS `loc` from `dept` where `dept`.`dname` = 'Sales' */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vw_emp_dept_info`
--

/*!50001 DROP VIEW IF EXISTS `vw_emp_dept_info`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `vw_emp_dept_info` AS select `emp`.`ename` AS `ename`,`emp`.`sal` AS `sal`,`dept`.`dname` AS `dname`,`dept`.`loc` AS `loc` from (`emp` join `dept` on(`emp`.`dno` = `dept`.`dno`)) where `dept`.`dname` = 'Finance' */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-08 10:42:58
